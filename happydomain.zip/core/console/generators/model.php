/**
 * Modelo <?= $class, PHP_EOL ?>
 * 
 * @category App
 * @package Models
 */
class <?= $class ?> extends ActiveRecord
{

}