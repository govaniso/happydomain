/**
 * Controlador <?= $class, PHP_EOL ?>
 * 
 * @category App
 * @package Controllers
 */
class <?= $class ?>Controller extends AppController
{

}
